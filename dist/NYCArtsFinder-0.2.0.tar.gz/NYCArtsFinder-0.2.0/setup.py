# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['nycartsfinder']

package_data = \
{'': ['*']}

install_requires = \
['geopy>=2.0.0,<3.0.0',
 'pandas>=1.1.5,<2.0.0',
 're>=2.2.1,<3.0.0',
 'requests>=2.25.1,<3.0.0']

setup_kwargs = {
    'name': 'nycartsfinder',
    'version': '0.2.0',
    'description': 'Package helps retrieve art events near your location.',
    'long_description': None,
    'author': 'Chengwei Wang',
    'author_email': 'chengwei.wendy.wang@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.8.6',
}


setup(**setup_kwargs)
