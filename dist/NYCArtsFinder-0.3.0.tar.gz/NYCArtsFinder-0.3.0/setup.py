# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['nycartsfinder']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'nycartsfinder',
    'version': '0.3.0',
    'description': 'Package helps retrieve art events near your location.',
    'long_description': None,
    'author': 'Chengwei Wang',
    'author_email': 'chengwei.wendy.wang@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '==3.8.6',
}


setup(**setup_kwargs)
